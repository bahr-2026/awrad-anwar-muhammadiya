import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppSettings.load();
  await NotificationService.init();
  runApp(const AwradApp());
}



class AppSettings {
  static final ValueNotifier<bool> darkMode = ValueNotifier(false);
  static final ValueNotifier<bool> haptics = ValueNotifier(true);
  static final ValueNotifier<double> defaultFontSize = ValueNotifier(23);
  static final ValueNotifier<bool> morningReminder = ValueNotifier(false);
  static final ValueNotifier<bool> eveningReminder = ValueNotifier(false);
  static final ValueNotifier<TimeOfDay> morningTime = ValueNotifier(const TimeOfDay(hour: 7, minute: 0));
  static final ValueNotifier<TimeOfDay> eveningTime = ValueNotifier(const TimeOfDay(hour: 18, minute: 0));

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    darkMode.value = p.getBool('dark_mode') ?? false;
    haptics.value = p.getBool('haptics') ?? true;
    defaultFontSize.value = p.getDouble('default_font_size') ?? 23;
    morningReminder.value = p.getBool('morning_reminder') ?? false;
    eveningReminder.value = p.getBool('evening_reminder') ?? false;
    morningTime.value = TimeOfDay(hour: p.getInt('morning_hour') ?? 7, minute: p.getInt('morning_minute') ?? 0);
    eveningTime.value = TimeOfDay(hour: p.getInt('evening_hour') ?? 18, minute: p.getInt('evening_minute') ?? 0);
  }

  static Future<void> setBool(String key, ValueNotifier<bool> n, bool v) async {
    n.value = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool(key, v);
  }
  static Future<void> setFont(double v) async {
    defaultFontSize.value = v;
    final p = await SharedPreferences.getInstance();
    await p.setDouble('default_font_size', v);
  }
  static Future<void> setTime(bool morning, TimeOfDay t) async {
    final p = await SharedPreferences.getInstance();
    final prefix = morning ? 'morning' : 'evening';
    if (morning) morningTime.value = t; else eveningTime.value = t;
    await p.setInt('${prefix}_hour', t.hour);
    await p.setInt('${prefix}_minute', t.minute);
  }
}

class NotificationService {
  static final FlutterLocalNotificationsPlugin plugin = FlutterLocalNotificationsPlugin();
  static Future<void> init() async {
    tz.initializeTimeZones();
    try {
      final zoneInfo = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(zoneInfo.identifier));
    } catch (_) {}
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    await plugin.initialize(const InitializationSettings(android: android, iOS: ios));
  }

  static Future<void> requestPermission() async {
    await plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
    await plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()?.requestPermissions(alert: true, badge: true, sound: true);
  }

  static tz.TZDateTime _next(TimeOfDay t) {
    final now = tz.TZDateTime.now(tz.local);
    var at = tz.TZDateTime(tz.local, now.year, now.month, now.day, t.hour, t.minute);
    if (at.isBefore(now)) at = at.add(const Duration(days: 1));
    return at;
  }

  static Future<void> scheduleDaily({required int id, required String title, required String body, required TimeOfDay time}) async {
    await requestPermission();
    const details = NotificationDetails(
      android: AndroidNotificationDetails('awrad_daily', 'تذكير الأوراد', channelDescription: 'تنبيهات يومية للأوراد', importance: Importance.high, priority: Priority.high),
      iOS: DarwinNotificationDetails(),
    );
    await plugin.zonedSchedule(id, title, body, _next(time), details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, matchDateTimeComponents: DateTimeComponents.time);
  }
  static Future<void> cancel(int id) => plugin.cancel(id);
}

class AwradApp extends StatelessWidget {
  const AwradApp({super.key});

  static const emerald = Color(0xFF0B4B3A);
  static const emeraldDark = Color(0xFF06372B);
  static const gold = Color(0xFFC79A3B);
  static const cream = Color(0xFFFFF8E8);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: AppSettings.darkMode,
      builder: (context, dark, _) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'أوراد الأنوار المحمدية',
      locale: const Locale('ar'),
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(
          seedColor: emerald,
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: emeraldDark,
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 0,
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: Color(0xFFE9DDBD),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(backgroundColor: emerald),
        ),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: emerald, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF071D18),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF052C23), foregroundColor: Colors.white, centerTitle: true),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xFF0B2C24), indicatorColor: Color(0xFF315D50)),
      ),
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      home: const SplashScreen(),
    ),
    );
  }
}

class WirdItem {
  final String id;
  final int number;
  final String? bookLabel;
  final String category;
  final String title;
  final String text;
  final int target;
  final String? source;
  final String? followUp;

  const WirdItem({
    required this.id,
    required this.number,
    this.bookLabel,
    required this.category,
    required this.title,
    required this.text,
    required this.target,
    this.source,
    this.followUp,
  });

  bool get isBookFollowUp => (bookLabel ?? '').startsWith('تابع');
  String get bookDisplayLabel => bookLabel == null ? '—' : bookLabel!;
}

const List<WirdItem> wirdItems = [
  WirdItem(
    id: 'w01',
    number: 1,
    bookLabel: '١',
    category: 'الآيات والسور',
    title: 'سورة الفاتحة',
    text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nالْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
    target: 100,
    source: 'سورة الفاتحة',
  ),
  WirdItem(
    id: 'w02',
    number: 2,
    bookLabel: '٢',
    category: 'الاستغفار',
    title: 'استغفار جامع',
    text: 'أستغفر الله العظيم لي ولوالدي، ولأصحاب الحقوق عليَّ، وللمسلمين والمسلمات، وللمؤمنين والمؤمنات، الأحياء منهم والأموات.',
    target: 100,
  ),
  WirdItem(
    id: 'w03',
    number: 3,
    bookLabel: '٣',
    category: 'الاستغفار',
    title: 'سيد الاستغفار',
    text: 'اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت، أعوذ بك من شر ما صنعت، أبوء لك بنعمتك عليَّ، وأبوء بذنبي، فاغفر لي؛ فإنه لا يغفر الذنوب إلا أنت.',
    target: 100,
  ),
  WirdItem(
    id: 'w03b',
    number: 4,
    bookLabel: 'تابع ٣',
    category: 'التحميد',
    title: 'حمدٌ لجلال الله',
    text: 'يا رب، لك الحمد كما ينبغي لجلال وجهك وعظيم سلطانك.',
    target: 33,
  ),
  WirdItem(
    id: 'w04',
    number: 5,
    bookLabel: '٤',
    category: 'الأدعية',
    title: 'دعاء العفو والرحمة',
    text: 'ربي لا إله إلا أنت، تُبتُ إليك، فاعفُ عني، واغفر لي، وارحمني، وأنت خير الراحمين.',
    target: 33,
  ),
  WirdItem(
    id: 'w05',
    number: 6,
    bookLabel: '٥',
    category: 'الاستغفار',
    title: 'الاستغفار والتوبة',
    text: 'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه.',
    target: 100,
  ),
  WirdItem(
    id: 'w06',
    number: 7,
    bookLabel: '٦',
    category: 'الأدعية',
    title: 'دعاء ذي النون',
    text: 'لا إله إلا أنت سبحانك إني كنت من الظالمين.',
    target: 100,
    source: 'سورة الأنبياء: 87',
  ),
  WirdItem(
    id: 'w07',
    number: 8,
    bookLabel: 'تابع ٦',
    category: 'الأدعية',
    title: 'دعاء النجاة من الهم',
    text: 'اللهم نجِّنا من الهم والغم والكرب العظيم.',
    target: 9,
  ),
  WirdItem(
    id: 'w08',
    number: 9,
    bookLabel: '٧',
    category: 'الآيات والسور',
    title: 'سورة الإخلاص',
    text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ',
    target: 100,
    source: 'سورة الإخلاص',
  ),
  WirdItem(
    id: 'w09',
    number: 10,
    bookLabel: '٨',
    category: 'الآيات والسور',
    title: 'سورة الشرح',
    text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nأَلَمْ نَشْرَحْ لَكَ صَدْرَكَ ۝ وَوَضَعْنَا عَنْكَ وِزْرَكَ ۝ الَّذِي أَنْقَضَ ظَهْرَكَ ۝ وَرَفَعْنَا لَكَ ذِكْرَكَ ۝ فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ فَإِذَا فَرَغْتَ فَانْصَبْ ۝ وَإِلَى رَبِّكَ فَارْغَبْ',
    target: 100,
    source: 'سورة الشرح',
  ),
  WirdItem(
    id: 'w10',
    number: 11,
    bookLabel: '٩',
    category: 'الصلاة على النبي ﷺ',
    title: 'صلاة عدد كمال الله',
    text: 'اللهم صلِّ وسلم وبارك على سيدنا محمد، وعلى آله، عدد كمال الله وكما يليق بكماله.',
    target: 500,
  ),
  WirdItem(
    id: 'w11',
    number: 12,
    bookLabel: '١٠',
    category: 'الصلاة على النبي ﷺ',
    title: 'صلاة الفرج',
    text: 'اللهم صلِّ وسلم وبارك على سيدنا محمد، الحبيب الشفيع الرؤوف الرحيم، الذي أخبر عن ربه الكريم: إن لله تعالى في كل نفس مائة ألف فرج قريب، وسلم.',
    target: 100,
  ),
  WirdItem(
    id: 'w12',
    number: 13,
    bookLabel: '١١',
    category: 'الصلاة على النبي ﷺ',
    title: 'الصلاة الفاتحية',
    text: 'اللهم صلِّ وسلم وبارك على سيدنا محمد، الفاتح لما أُغلق، والخاتم لما سبق، ناصر الحق بالحق، والهادي إلى صراط الله المستقيم، وعلى آله حق قدره ومقداره العظيم.',
    target: 100,
  ),
  WirdItem(
    id: 'w13',
    number: 14,
    bookLabel: '١٢',
    category: 'التهليل والتسبيح',
    title: 'التهليل',
    text: 'لا إله إلا الله.',
    target: 500,
  ),
  WirdItem(
    id: 'w14',
    number: 15,
    bookLabel: '١٣',
    category: 'التهليل والتسبيح',
    title: 'التسبيح والتحميد',
    text: 'سبحان الله وبحمده، سبحان الله العظيم.',
    target: 200,
  ),
  WirdItem(
    id: 'w15',
    number: 16,
    bookLabel: '١٤',
    category: 'التهليل والتسبيح',
    title: 'سبحان الله وبحمده',
    text: 'سبحان الله وبحمده، عدد خلقه، ورضا نفسه، وزنة عرشه، ومداد كلماته.',
    target: 100,
  ),
  WirdItem(
    id: 'w16',
    number: 17,
    bookLabel: '١٥',
    category: 'التهليل والتسبيح',
    title: 'سبحانك اللهم وبحمدك',
    text: 'سبحانك اللهم وبحمدك، وتبارك اسمك، وتعالى جدك، ولا إله غيرك.',
    target: 100,
  ),
  WirdItem(
    id: 'w17',
    number: 18,
    bookLabel: '١٦',
    category: 'التهليل والتسبيح',
    title: 'الباقيات الصالحات',
    text: 'سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر، ولا حول ولا قوة إلا بالله العلي العظيم.',
    target: 100,
  ),
  WirdItem(
    id: 'w18',
    number: 19,
    bookLabel: '١٧',
    category: 'الآيات والسور',
    title: 'آية الكرسي',
    text: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
    target: 100,
    source: 'سورة البقرة: 255',
  ),
  WirdItem(
    id: 'w19',
    number: 20,
    bookLabel: '١٨',
    category: 'الآيات والسور',
    title: 'سورة العصر',
    text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nوَالْعَصْرِ ۝ إِنَّ الْإِنْسَانَ لَفِي خُسْرٍ ۝ إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ',
    target: 100,
    source: 'سورة العصر',
  ),
];

const List<WirdItem> fridayItems = [
  WirdItem(
    id: 'f01',
    number: 1,
    category: 'ورد بعد صلاة الجمعة',
    title: 'سورة النصر',
    text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nإِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ ۝ وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا ۝ فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا',
    target: 10,
    source: 'سورة النصر',
  ),
  WirdItem(
    id: 'f02',
    number: 2,
    category: 'ورد بعد صلاة الجمعة',
    title: 'آية الاستغفار',
    text: 'وَمَنْ يَعْمَلْ سُوءًا أَوْ يَظْلِمْ نَفْسَهُ ثُمَّ يَسْتَغْفِرِ اللَّهَ يَجِدِ اللَّهَ غَفُورًا رَحِيمًا',
    target: 10,
    source: 'سورة النساء: 110',
  ),
  WirdItem(
    id: 'f03',
    number: 3,
    category: 'ورد بعد صلاة الجمعة',
    title: 'وما كان الله ليعذبهم',
    text: 'وَمَا كَانَ اللَّهُ لِيُعَذِّبَهُمْ وَأَنْتَ فِيهِمْ ۚ وَمَا كَانَ اللَّهُ مُعَذِّبَهُمْ وَهُمْ يَسْتَغْفِرُونَ',
    target: 10,
    source: 'سورة الأنفال: 33',
  ),
  WirdItem(
    id: 'f04',
    number: 4,
    category: 'ورد بعد صلاة الجمعة',
    title: 'أستغفر الله العظيم',
    text: 'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه.',
    target: 33,
  ),
  WirdItem(
    id: 'f05',
    number: 5,
    category: 'ورد بعد صلاة الجمعة',
    title: 'استغفار جامع',
    text: 'أستغفر الله العظيم لي ولوالدي، ولأصحاب الحقوق عليَّ، وللمسلمين والمسلمات، وللمؤمنين والمؤمنات، الأحياء منهم والأموات.',
    target: 33,
  ),
  WirdItem(
    id: 'f06',
    number: 6,
    category: 'ورد بعد صلاة الجمعة',
    title: 'استغفار قيوم السماوات والأرض',
    text: 'أستغفر الله العظيم قيوم السماوات والأرض، برحمن الرحيم، والحمد لله رب العالمين.',
    target: 33,
  ),
  WirdItem(
    id: 'f07',
    number: 7,
    category: 'ورد بعد صلاة الجمعة',
    title: 'الحمد لله رب العالمين',
    text: 'الحمد لله رب العالمين، يا رب لك الحمد كما ينبغي لجلال وجهك وعظيم سلطانك.',
    target: 33,
  ),
  WirdItem(
    id: 'f08',
    number: 8,
    category: 'ورد بعد صلاة الجمعة',
    title: 'الحمد لله دائمًا',
    text: 'الحمد لله دائمًا، لا نهاية لحمده، حمدًا طيبًا مباركًا فيه.',
    target: 33,
  ),
  WirdItem(
    id: 'f09',
    number: 9,
    category: 'ورد بعد صلاة الجمعة',
    title: 'آية الصلاة على النبي ﷺ',
    text: 'إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ ۚ يَا أَيُّهَا الَّذِينَ آمَنُوا صَلُّوا عَلَيْهِ وَسَلِّمُوا تَسْلِيمًا',
    target: 1,
    source: 'سورة الأحزاب: 56',
  ),
  WirdItem(
    id: 'f10',
    number: 10,
    category: 'ورد بعد صلاة الجمعة',
    title: 'صلاة عدد كمال الله',
    text: 'اللهم صلِّ وسلم وبارك على سيدنا محمد، وعلى آله، عدد كمال الله وكما يليق بكماله.',
    target: 33,
  ),
  WirdItem(
    id: 'f11',
    number: 11,
    category: 'ورد بعد صلاة الجمعة',
    title: 'خير ما قلت أنا والنبيون',
    text: 'لا إله إلا الله.',
    target: 500,
  ),
  WirdItem(
    id: 'f12',
    number: 12,
    category: 'ورد بعد صلاة الجمعة',
    title: 'الله لا إله إلا هو الحي',
    text: 'الله لا إله إلا الله، هو الحي.',
    target: 100,
  ),
  WirdItem(
    id: 'f13',
    number: 13,
    category: 'ورد بعد صلاة الجمعة',
    title: 'نسألك رضاك والجنة',
    text: 'اللهم إنا نسألك رضاك والجنة، ونعوذ بك من سخطك والنار.',
    target: 10,
  ),
  WirdItem(
    id: 'f14',
    number: 14,
    category: 'ورد بعد صلاة الجمعة',
    title: 'نسألك حسن لقائك',
    text: 'اللهم إنا نسألك رضاك، وحسن لقائك، والجنة والفردوس الأعلى بفضلك وكرمك، يا خير من سُئل، ويا أكرم من أعطى، يا الله.',
    target: 3,
  ),
  WirdItem(
    id: 'f15',
    number: 15,
    category: 'ورد بعد صلاة الجمعة',
    title: 'يا الله',
    text: 'يا الله، يا الله.',
    target: 9,
  ),
  WirdItem(
    id: 'f16',
    number: 16,
    category: 'ورد بعد صلاة الجمعة',
    title: 'دعاء تيسير الشديد',
    text: 'بالله بالله، يا مسهِّل الشديد، يا مليِّن الحديد، أخرجنا من حلقة الضيق إلى سعة الطريق، وادفع عنا ما لا نطيق. إن الله يدافع عن الذين آمنوا.',
    target: 3,
  ),
  WirdItem(
    id: 'f17',
    number: 17,
    category: 'ورد بعد صلاة الجمعة',
    title: 'الله دائم باق حي',
    text: 'الله دائم باق حي.',
    target: 33,
  ),
  WirdItem(
    id: 'f18',
    number: 18,
    category: 'ورد بعد صلاة الجمعة',
    title: 'الفاتحة',
    text: 'سورة الفاتحة.',
    target: 1,
    source: 'سورة الفاتحة',
  ),
];

const List<WirdItem> openingItems = [
  WirdItem(
    id: 'o01',
    number: 1,
    category: 'افتتاح الورد',
    title: 'آية العلم المحيط',
    text: 'أَلَمْ تَرَ أَنَّ اللَّهَ يَعْلَمُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۖ مَا يَكُونُ مِنْ نَجْوَىٰ ثَلَاثَةٍ إِلَّا هُوَ رَابِعُهُمْ وَلَا خَمْسَةٍ إِلَّا هُوَ سَادِسُهُمْ وَلَا أَدْنَىٰ مِنْ ذَٰلِكَ وَلَا أَكْثَرَ إِلَّا هُوَ مَعَهُمْ أَيْنَ مَا كَانُوا ۖ ثُمَّ يُنَبِّئُهُمْ بِمَا عَمِلُوا يَوْمَ الْقِيَامَةِ ۚ إِنَّ اللَّهَ بِكُلِّ شَيْءٍ عَلِيمٌ',
    target: 1,
    source: 'سورة المجادلة: 7',
  ),
  WirdItem(
    id: 'o02',
    number: 2,
    category: 'افتتاح الورد',
    title: 'آيات الولاية والبشرى',
    text: 'وَمَا تَكُونُ فِي شَأْنٍ وَمَا تَتْلُو مِنْهُ مِنْ قُرْآنٍ وَلَا تَعْمَلُونَ مِنْ عَمَلٍ إِلَّا كُنَّا عَلَيْكُمْ شُهُودًا إِذْ تُفِيضُونَ فِيهِ ۚ وَمَا يَعْزُبُ عَنْ رَبِّكَ مِنْ مِثْقَالِ ذَرَّةٍ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَلَا أَصْغَرَ مِنْ ذَٰلِكَ وَلَا أَكْبَرَ إِلَّا فِي كِتَابٍ مُبِينٍ ۝ أَلَا إِنَّ أَوْلِيَاءَ اللَّهِ لَا خَوْفٌ عَلَيْهِمْ وَلَا هُمْ يَحْزَنُونَ ۝ الَّذِينَ آمَنُوا وَكَانُوا يَتَّقُونَ ۝ لَهُمُ الْبُشْرَىٰ فِي الْحَيَاةِ الدُّنْيَا وَفِي الْآخِرَةِ ۚ لَا تَبْدِيلَ لِكَلِمَاتِ اللَّهِ ۚ ذَٰلِكَ هُوَ الْفَوْزُ الْعَظِيمُ',
    target: 1,
    source: 'سورة يونس: 61–64',
  ),
];

const String closingText = 'أنا لا أُضامُ وخيرُ الخلقِ لي سندٌ، جعلتُه عُمدتي في كلِّ أحوالي.';

const WirdItem closingItem = WirdItem(
  id: 'c01',
  number: 1,
  category: 'ختام الورد',
  title: 'ختام الورد',
  text: closingText,
  target: 1,
);

List<WirdItem> get fullWirdSequence => [...openingItems, ...wirdItems, closingItem];
List<WirdItem> get allItems => [...fullWirdSequence, ...fridayItems];


const String contentRevision = 'مراجعة المحتوى: صور الكتيب الأصلية – الإصدار 0.8';

class CounterStore {
  static String _key(String id) => 'count_$id';
  static String _favKey(String id) => 'fav_$id';

  static Future<int> getCount(String id) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_key(id)) ?? 0;
  }

  static Future<void> setCount(String id, int value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_key(id), value);
  }

  static Future<bool> isFavorite(String id) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_favKey(id)) ?? false;
  }

  static Future<void> setFavorite(String id, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_favKey(id), value);
  }

  static Future<void> resetAll() async {
    final prefs = await SharedPreferences.getInstance();
    for (final item in allItems) {
      await prefs.remove(_key(item.id));
    }
  }
}


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1700), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AwradApp.emeraldDark,
      body: SafeArea(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 34),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [AwradApp.emeraldDark, Color(0xFF0C5944)],
            ),
          ),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AwradApp.gold, width: 2),
                  color: const Color(0x142CFFC0),
                ),
                child: const Center(
                  child: Text(
                    'ﷺ',
                    style: TextStyle(color: Color(0xFFFFE7A4), fontSize: 42, fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              const SizedBox(height: 26),
              const Text(
                'أوراد الأنوار المحمدية',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFFFE7A4), fontSize: 31, height: 1.35, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              const Text(
                'للأذكار والأوراد والأدعية\nإعداد/ د. أحمد حسن البحراوي\nالإصدار 1.1',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 34),
              const Icon(Icons.auto_awesome, color: AwradApp.gold),
              const SizedBox(height: 10),
              const Text(
                '﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, height: 1.8, fontSize: 18),
              ),
              const Spacer(),
              const SizedBox(
                width: 34,
                height: 34,
                child: CircularProgressIndicator(strokeWidth: 2.5, color: AwradApp.gold),
              ),
              const SizedBox(height: 18),
            ],
          ),
        ),
      ),
    );
  }
}

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final q = query.trim();
    final results = q.isEmpty
        ? allItems
        : allItems.where((item) {
            final haystack = '${item.title} ${item.text} ${item.category} ${item.source ?? ''}';
            return haystack.contains(q);
          }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('البحث في الأوراد', style: TextStyle(fontWeight: FontWeight.w900))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: TextField(
              autofocus: true,
              onChanged: (value) => setState(() => query = value),
              decoration: InputDecoration(
                hintText: 'اكتب كلمة من الذكر أو اسم الورد…',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFFE8D9B3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFFE8D9B3)),
                ),
              ),
            ),
          ),
          Expanded(
            child: results.isEmpty
                ? const Center(child: Text('لا توجد نتائج مطابقة.'))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
                    itemCount: results.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 9),
                    itemBuilder: (_, index) => WirdListTile(item: results[index]),
                  ),
          ),
        ],
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      const HomeTab(),
      const WirdTodayScreen(),
      const FavoritesScreen(),
      const MoreScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: selectedIndex, children: screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (value) => setState(() => selectedIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.check_circle_outline), label: 'وِردي'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'المزيد'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: _HomeHeroHeader()),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(14, 16, 14, 28),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  const _FullWirdLaunchCard(),
                  const SizedBox(height: 16),
                  const _QuickActionsRow(),
                  const SizedBox(height: 20),
                  const _SectionTitle(title: 'شيوخ السلسلة'),
                  const SizedBox(height: 10),
                  const _SheikhsCard(),
                  const SizedBox(height: 22),
                  const _SectionTitle(title: 'أقسام الأوراد'),
                  const SizedBox(height: 10),
                  const _CategoriesGrid(),
                  const SizedBox(height: 22),
                  const _SectionTitle(title: 'وِردي اليوم'),
                  const SizedBox(height: 10),
                  const _DynamicDailyProgressCard(),
                  const SizedBox(height: 18),
                  const _VerseBanner(),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeHeroHeader extends StatelessWidget {
  const _HomeHeroHeader();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 10, 10, 0),
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF06372B), Color(0xFF0B4B3A), Color(0xFF14614C)],
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AwradApp.gold, width: 1.2),
        boxShadow: const [
          BoxShadow(color: Color(0x26000000), blurRadius: 22, offset: Offset(0, 10)),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            left: -22,
            top: -30,
            child: Icon(Icons.auto_awesome, size: 120, color: Colors.white.withOpacity(.035)),
          ),
          Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.10),
                      shape: BoxShape.circle,
                      border: Border.all(color: AwradApp.gold.withOpacity(.65)),
                    ),
                    child: IconButton(
                      tooltip: 'بحث',
                      padding: EdgeInsets.zero,
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const SearchScreen()),
                      ),
                      icon: const Icon(Icons.search_rounded, color: Colors.white),
                    ),
                  ),
                  const Expanded(
                    child: Text(
                      'أوراد الأنوار المحمدية',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFFFFE8A8),
                        fontSize: 23,
                        fontWeight: FontWeight.w900,
                        height: 1.25,
                      ),
                    ),
                  ),
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.10),
                      shape: BoxShape.circle,
                      border: Border.all(color: AwradApp.gold.withOpacity(.65)),
                    ),
                    child: const Icon(Icons.mosque_rounded, color: Color(0xFFFFE8A8)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const _OrnamentDivider(),
              const SizedBox(height: 12),
              const Text(
                'مرحبًا بك في رحاب الذكر والطمأنينة',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 7),
              const Text(
                'اجعل لك وِردًا يضيء قلبك ويعمر يومك بذكر الله',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFF2E5C5), fontSize: 14.5, height: 1.55),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _OrnamentDivider extends StatelessWidget {
  const _OrnamentDivider();

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(width: 44, height: 1, color: AwradApp.gold.withOpacity(.6)),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Icon(Icons.auto_awesome, size: 16, color: AwradApp.gold),
          ),
          Container(width: 44, height: 1, color: AwradApp.gold.withOpacity(.6)),
        ],
      );
}

class _QuickActionsRow extends StatelessWidget {
  const _QuickActionsRow();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _QuickAction(
            icon: Icons.search_rounded,
            title: 'بحث',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen())),
          ),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: _QuickAction(
            icon: Icons.favorite_rounded,
            title: 'المفضلة',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FavoritesScreen())),
          ),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: _QuickAction(
            icon: Icons.info_outline_rounded,
            title: 'عن الشيخين',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SheikhsInfoScreen())),
          ),
        ),
      ],
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _QuickAction({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: const Color(0xFFE5D4A9)),
            ),
            child: Column(
              children: [
                Icon(icon, color: AwradApp.emerald, size: 25),
                const SizedBox(height: 5),
                Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
              ],
            ),
          ),
        ),
      );
}

class _FullWirdLaunchCard extends StatefulWidget {
  const _FullWirdLaunchCard();

  @override
  State<_FullWirdLaunchCard> createState() => _FullWirdLaunchCardState();
}

class _FullWirdLaunchCardState extends State<_FullWirdLaunchCard> {
  int completed = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    var done = 0;
    for (final item in fullWirdSequence) {
      final count = await CounterStore.getCount(item.id);
      if (count >= item.target) done++;
    }
    if (mounted) setState(() => completed = done);
  }

  @override
  Widget build(BuildContext context) {
    final total = fullWirdSequence.length;
    final progress = total == 0 ? 0.0 : completed / total;
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFFF7E5), Color(0xFFFFEEC7)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFD8B05B)),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 14, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(color: AwradApp.emerald, borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.auto_stories_rounded, color: Colors.white, size: 27),
              ),
              const SizedBox(width: 11),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('الورد الكامل', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AwradApp.emeraldDark)),
                    SizedBox(height: 2),
                    Text('من الافتتاح إلى الختام بالترتيب', style: TextStyle(color: Colors.black54, fontSize: 12.5)),
                  ],
                ),
              ),
              Text('$completed/$total', style: const TextStyle(color: AwradApp.emerald, fontWeight: FontWeight.w900)),
            ],
          ),
          const SizedBox(height: 13),
          LinearProgressIndicator(
            value: progress,
            minHeight: 8,
            borderRadius: BorderRadius.circular(20),
            color: AwradApp.emerald,
            backgroundColor: const Color(0xFFE7DCC2),
          ),
          const SizedBox(height: 13),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 13),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            onPressed: () async {
              await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FullWirdSessionScreen()));
              _load();
            },
            icon: Icon(completed == 0 ? Icons.play_arrow_rounded : Icons.play_circle_outline_rounded),
            label: Text(completed == 0 ? 'ابدأ الورد' : 'متابعة من حيث توقفت'),
          ),
        ],
      ),
    );
  }
}

class _SheikhsCard extends StatelessWidget {
  const _SheikhsCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE3CD95)),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 15, offset: Offset(0, 7))],
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: _PortraitCard(
              asset: 'assets/images/sheikh_abdelrahim.jpg',
              name: 'العارف بالله الشيخ\nعبدالرحيم إبراهيم البحراوي',
            ),
          ),
          SizedBox(width: 10),
          Expanded(
            child: _PortraitCard(
              asset: 'assets/images/sheikh_ibrahim.jpg',
              name: 'العارف بالله الشيخ\nإبراهيم عبدالرحيم البحراوي',
            ),
          ),
        ],
      ),
    );
  }
}

class _PortraitCard extends StatelessWidget {
  final String asset;
  final String name;

  const _PortraitCard({required this.asset, required this.name});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFD5AD54), Color(0xFFF4D98D), Color(0xFFB8892B)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(19),
            child: AspectRatio(
              aspectRatio: .82,
              child: Image.asset(asset, fit: BoxFit.cover, alignment: Alignment.topCenter),
            ),
          ),
        ),
        const SizedBox(height: 9),
        Text(
          name,
          textAlign: TextAlign.center,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: AwradApp.emeraldDark, height: 1.35, fontWeight: FontWeight.w900, fontSize: 12.5),
        ),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;

  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Container(
            width: 6,
            height: 26,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AwradApp.gold, Color(0xFFE2C36D)]),
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(width: 9),
          Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AwradApp.emeraldDark)),
        ],
      );
}

class _CategoriesGrid extends StatelessWidget {
  const _CategoriesGrid();

  @override
  Widget build(BuildContext context) => GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        childAspectRatio: 1.28,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        children: [
          _CategoryCard(Icons.menu_book_rounded, 'الورد الأساسي', wirdItems),
          _CategoryCard(Icons.mosque_outlined, 'ورد بعد صلاة الجمعة', fridayItems),
          _CategoryCard(Icons.auto_stories_outlined, 'الآيات والسور', wirdItems.where((e) => e.category == 'الآيات والسور').toList()),
          _CategoryCard(Icons.favorite_outline, 'الصلاة على النبي ﷺ', wirdItems.where((e) => e.category == 'الصلاة على النبي ﷺ').toList()),
          _CategoryCard(Icons.water_drop_outlined, 'الاستغفار', wirdItems.where((e) => e.category == 'الاستغفار').toList()),
          _CategoryCard(Icons.brightness_7_outlined, 'التهليل والتسبيح', wirdItems.where((e) => e.category == 'التهليل والتسبيح').toList()),
          _CategoryCard(Icons.front_hand_outlined, 'الأدعية', wirdItems.where((e) => e.category == 'الأدعية').toList()),
          _CategoryCard(Icons.verified_outlined, 'التحميد', wirdItems.where((e) => e.category == 'التحميد').toList()),
        ],
      );
}

class _CategoryCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final List<WirdItem> items;

  const _CategoryCard(this.icon, this.title, this.items);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => WirdListScreen(title: title, items: items))),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE8D9B3)),
            boxShadow: const [BoxShadow(color: Color(0x0D000000), blurRadius: 10, offset: Offset(0, 4))],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 49,
                height: 49,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFF7EEDB), Color(0xFFFFF9EA)]),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFE7D29E)),
                ),
                child: Icon(icon, color: AwradApp.emerald, size: 27),
              ),
              const SizedBox(height: 8),
              Text(title, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.25, fontSize: 13.2)),
              const SizedBox(height: 3),
              Text('${items.length} ورد', style: const TextStyle(fontSize: 10.8, color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }
}

class _DynamicDailyProgressCard extends StatefulWidget {
  const _DynamicDailyProgressCard();

  @override
  State<_DynamicDailyProgressCard> createState() => _DynamicDailyProgressCardState();
}

class _DynamicDailyProgressCardState extends State<_DynamicDailyProgressCard> {
  double progress = 0;
  int complete = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    int done = 0;
    for (final item in wirdItems) {
      final count = await CounterStore.getCount(item.id);
      if (count >= item.target) done++;
    }
    if (!mounted) return;
    setState(() {
      complete = done;
      progress = wirdItems.isEmpty ? 0 : done / wirdItems.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    final percent = (progress * 100).round();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE8D9B3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: Text('أتممت $complete من ${wirdItems.length} وردًا', style: const TextStyle(fontWeight: FontWeight.w900))),
              Text('$percent٪', style: const TextStyle(color: AwradApp.emerald, fontWeight: FontWeight.w900)),
            ],
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: progress,
            minHeight: 9,
            borderRadius: BorderRadius.circular(20),
            color: AwradApp.emerald,
            backgroundColor: const Color(0xFFECE6D8),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: () async {
              await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const WirdTodayScreen()));
              _load();
            },
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('متابعة الورد'),
          ),
        ],
      ),
    );
  }
}

class _VerseBanner extends StatelessWidget {
  const _VerseBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
      decoration: BoxDecoration(
        color: AwradApp.emeraldDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AwradApp.gold),
      ),
      child: const Text(
        '﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾',
        textAlign: TextAlign.center,
        style: TextStyle(color: Color(0xFFFFE7A4), fontSize: 18, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class WirdListScreen extends StatelessWidget {
  final String title;
  final List<WirdItem> items;

  const WirdListScreen({super.key, required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
      body: items.isEmpty
          ? const Center(child: Text('لا توجد أوراد في هذا القسم بعد.'))
          : ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 9),
              itemBuilder: (_, index) => WirdListTile(item: items[index]),
            ),
    );
  }
}

class WirdListTile extends StatefulWidget {
  final WirdItem item;

  const WirdListTile({super.key, required this.item});

  @override
  State<WirdListTile> createState() => _WirdListTileState();
}

class _WirdListTileState extends State<WirdListTile> {
  int count = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final value = await CounterStore.getCount(widget.item.id);
    if (mounted) setState(() => count = value);
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final done = count >= item.target;
    final progress = item.target == 0 ? 0.0 : (count / item.target).clamp(0.0, 1.0);
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => CounterScreen(item: item)));
          _load();
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: done ? const Color(0xFFE0F1E7) : const Color(0xFFF4EBD5),
                    child: done
                        ? const Icon(Icons.check_rounded, color: AwradApp.emerald)
                        : Text(item.bookLabel ?? '${item.number}', style: const TextStyle(fontWeight: FontWeight.w900, color: AwradApp.emeraldDark)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
                  Text('$count / ${item.target}', style: TextStyle(fontWeight: FontWeight.w800, color: done ? AwradApp.emerald : Colors.black54)),
                ],
              ),
              const SizedBox(height: 9),
              Wrap(
                spacing: 7,
                runSpacing: 6,
                children: [
                  if (item.bookLabel != null)
                    _MetaPill(
                      icon: item.isBookFollowUp ? Icons.subdirectory_arrow_left_rounded : Icons.menu_book_rounded,
                      label: item.isBookFollowUp ? item.bookDisplayLabel : 'الكتيب ${item.bookDisplayLabel}',
                      emphasis: item.isBookFollowUp,
                    ),
                  _MetaPill(icon: Icons.repeat_rounded, label: '${item.target} مرة'),
                ],
              ),
              const SizedBox(height: 10),
              LinearProgressIndicator(
                value: progress,
                minHeight: 6,
                borderRadius: BorderRadius.circular(20),
                color: AwradApp.emerald,
                backgroundColor: const Color(0xFFECE6D8),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _WirdMetaStrip extends StatelessWidget {
  final WirdItem item;
  final String targetText;
  const _WirdMetaStrip({required this.item, required this.targetText});

  @override
  Widget build(BuildContext context) {
    final hasBookNumber = item.bookLabel != null;
    final isFollow = item.isBookFollowUp;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: [
        if (hasBookNumber)
          _MetaPill(
            icon: isFollow ? Icons.subdirectory_arrow_left_rounded : Icons.menu_book_rounded,
            label: isFollow ? 'تابع للورد ${item.bookLabel!.replaceFirst('تابع ', '')}' : 'رقم الورد في الكتيب: ${item.bookDisplayLabel}',
            emphasis: isFollow,
          ),
        _MetaPill(icon: Icons.repeat_rounded, label: 'العدد المطلوب: $targetText'),
        _MetaPill(icon: Icons.category_outlined, label: item.category),
      ],
    );
  }
}

class _MetaPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool emphasis;
  const _MetaPill({required this.icon, required this.label, this.emphasis = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        color: emphasis ? const Color(0xFFFFF1C7) : const Color(0xFFF5EEDC),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: emphasis ? AwradApp.gold : const Color(0xFFE6D7B1)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 17, color: AwradApp.emeraldDark),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: AwradApp.emeraldDark, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class CounterScreen extends StatefulWidget {
  final WirdItem item;

  const CounterScreen({super.key, required this.item});

  @override
  State<CounterScreen> createState() => _CounterScreenState();
}

class _CounterScreenState extends State<CounterScreen> {
  int count = 0;
  bool favorite = false;
  double fontSize = AppSettings.defaultFontSize.value;
  bool _completionShown = false;

  List<WirdItem> get _sequence {
    if (widget.item.id.startsWith('f')) return fridayItems;
    if (widget.item.id.startsWith('o') || widget.item.id.startsWith('c')) return fullWirdSequence;
    return wirdItems;
  }

  int get _index => _sequence.indexWhere((e) => e.id == widget.item.id);
  WirdItem? get _nextItem => (_index >= 0 && _index < _sequence.length - 1) ? _sequence[_index + 1] : null;
  WirdItem? get _previousItem => (_index > 0 && _index < _sequence.length) ? _sequence[_index - 1] : null;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await CounterStore.getCount(widget.item.id);
    final f = await CounterStore.isFavorite(widget.item.id);
    if (!mounted) return;
    setState(() {
      count = c;
      favorite = f;
      _completionShown = c >= widget.item.target;
    });
  }

  Future<void> _increment() async {
    if (count >= widget.item.target) return;
    if (AppSettings.haptics.value) HapticFeedback.selectionClick();
    final next = count + 1;
    setState(() => count = next);
    await CounterStore.setCount(widget.item.id, next);
    if (next >= widget.item.target && !_completionShown && mounted) {
      _completionShown = true;
      if (AppSettings.haptics.value) HapticFeedback.mediumImpact();
      await _showCompletedDialog();
    }
  }

  Future<void> _showCompletedDialog() async {
    final next = _nextItem;
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.check_circle_rounded, color: AwradApp.emerald, size: 50),
        title: const Text('تم الورد بحمد الله', textAlign: TextAlign.center),
        content: Text(
          next == null ? 'أتممت هذا القسم، نسأل الله القبول.' : 'اكتمل العدد المحدد لهذا الذكر. يمكنك الانتقال إلى الذكر التالي.',
          textAlign: TextAlign.center,
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('البقاء هنا')),
          if (next != null)
            FilledButton.icon(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CounterScreen(item: next)));
              },
              icon: const Icon(Icons.arrow_back_rounded),
              label: const Text('الذكر التالي'),
            ),
        ],
      ),
    );
  }

  Future<void> _decrement() async {
    if (count <= 0) return;
    if (AppSettings.haptics.value) HapticFeedback.selectionClick();
    final next = count - 1;
    setState(() {
      count = next;
      _completionShown = false;
    });
    await CounterStore.setCount(widget.item.id, next);
  }

  Future<void> _reset() async {
    final ok = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('إعادة العداد'),
            content: const Text('هل تريد تصفير عداد هذا الورد؟'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تصفير')),
            ],
          ),
        ) ??
        false;
    if (!ok) return;
    setState(() {
      count = 0;
      _completionShown = false;
    });
    await CounterStore.setCount(widget.item.id, 0);
  }

  void _goTo(WirdItem item) {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CounterScreen(item: item)));
  }

  String _arNum(int n) {
    const western = '0123456789';
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    return n.toString().split('').map((c) {
      final i = western.indexOf(c);
      return i < 0 ? c : arabic[i];
    }).join();
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final done = count >= item.target;
    final progress = item.target == 0 ? 0.0 : (count / item.target).clamp(0.0, 1.0);
    final next = _nextItem;
    final previous = _previousItem;
    final remaining = (item.target - count).clamp(0, item.target);

    return Scaffold(
      appBar: AppBar(
        title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            tooltip: favorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة',
            onPressed: () async {
              setState(() => favorite = !favorite);
              await CounterStore.setFavorite(item.id, favorite);
            },
            icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            LinearProgressIndicator(
              value: _index < 0 || _sequence.isEmpty ? 0 : (_index + 1) / _sequence.length,
              minHeight: 5,
              color: AwradApp.gold,
              backgroundColor: const Color(0xFFECE6D8),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          _index >= 0 ? 'الورد ${_arNum(_index + 1)} من ${_arNum(_sequence.length)} • ${item.category}' : item.category,
                          style: const TextStyle(color: AwradApp.emerald, fontWeight: FontWeight.w900),
                        ),
                      ),
                      IconButton(
                        tooltip: 'تصغير الخط',
                        onPressed: fontSize <= 18 ? null : () => setState(() => fontSize -= 2),
                        icon: const Icon(Icons.text_decrease_rounded),
                      ),
                      IconButton(
                        tooltip: 'تكبير الخط',
                        onPressed: fontSize >= 35 ? null : () => setState(() => fontSize += 2),
                        icon: const Icon(Icons.text_increase_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 22),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: const Color(0xFFE8D9B3)),
                      boxShadow: const [BoxShadow(color: Color(0x11000000), blurRadius: 18, offset: Offset(0, 7))],
                    ),
                    child: Column(
                      children: [
                        _WirdMetaStrip(item: item, targetText: '${_arNum(item.target)} مرة'),
                        const SizedBox(height: 18),
                        Text(item.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, color: AwradApp.emeraldDark, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 16),
                        SelectableText(
                          item.text,
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: fontSize, height: 1.95, fontWeight: FontWeight.w700),
                        ),
                        if (item.source != null) ...[
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                            decoration: BoxDecoration(color: const Color(0xFFF5EEDC), borderRadius: BorderRadius.circular(30)),
                            child: Text(item.source!, style: const TextStyle(color: AwradApp.emeraldDark, fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Semantics(
                    button: true,
                    label: done ? 'اكتمل العدد المحدد' : 'زيادة عداد الذكر مرة واحدة',
                    child: InkWell(
                      onTap: done ? null : _increment,
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
                        decoration: BoxDecoration(
                          color: AwradApp.emeraldDark,
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: AwradApp.gold, width: 1.4),
                          boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 18, offset: Offset(0, 8))],
                        ),
                        child: Column(
                          children: [
                            Text(
                              done ? 'تم الورد ✓' : 'اضغط على الدائرة مع كل تكرار',
                              style: const TextStyle(color: Color(0xFFFFE7A4), fontSize: 18, fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 18),
                            SizedBox(
                              width: 178,
                              height: 178,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  SizedBox(
                                    width: 178,
                                    height: 178,
                                    child: CircularProgressIndicator(
                                      value: progress,
                                      strokeWidth: 11,
                                      color: AwradApp.gold,
                                      backgroundColor: const Color(0xFF315D50),
                                      strokeCap: StrokeCap.round,
                                    ),
                                  ),
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(_arNum(count), style: const TextStyle(color: Colors.white, fontSize: 52, height: 1, fontWeight: FontWeight.w900)),
                                      const SizedBox(height: 7),
                                      Text('من ${_arNum(item.target)}', style: const TextStyle(color: Colors.white70, fontSize: 17, fontWeight: FontWeight.w800)),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              done ? 'أحسنت، اكتمل العدد المحدد.' : 'متبقي ${_arNum(remaining)} مرة',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: OutlinedButton.icon(onPressed: count == 0 ? null : _decrement, icon: const Icon(Icons.undo_rounded), label: const Text('تراجع'))),
                      const SizedBox(width: 10),
                      Expanded(child: OutlinedButton.icon(onPressed: _reset, icon: const Icon(Icons.restart_alt_rounded), label: const Text('تصفير'))),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(14, 9, 14, 12),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [BoxShadow(color: Color(0x11000000), blurRadius: 10, offset: Offset(0, -3))],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: previous == null ? null : () => _goTo(previous),
                      icon: const Icon(Icons.arrow_forward_rounded),
                      label: const Text('السابق'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: next == null ? null : () => _goTo(next),
                      icon: const Icon(Icons.arrow_back_rounded),
                      label: const Text('التالي'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FullWirdSessionScreen extends StatefulWidget {
  const FullWirdSessionScreen({super.key});

  @override
  State<FullWirdSessionScreen> createState() => _FullWirdSessionScreenState();
}

class _FullWirdSessionScreenState extends State<FullWirdSessionScreen> {
  int completed = 0;
  int startIndex = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    var done = 0;
    var firstIncomplete = -1;
    for (var i = 0; i < fullWirdSequence.length; i++) {
      final item = fullWirdSequence[i];
      final count = await CounterStore.getCount(item.id);
      if (count >= item.target) {
        done++;
      } else if (firstIncomplete == -1) {
        firstIncomplete = i;
      }
    }
    if (!mounted) return;
    setState(() {
      completed = done;
      startIndex = firstIncomplete == -1 ? 0 : firstIncomplete;
      loading = false;
    });
  }

  Future<void> _openAt(int index) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => FullWirdReaderScreen(initialIndex: index)),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final total = fullWirdSequence.length;
    final progress = total == 0 ? 0.0 : completed / total;
    return Scaffold(
      appBar: AppBar(title: const Text('الورد الكامل', style: TextStyle(fontWeight: FontWeight.w900))),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AwradApp.emeraldDark, AwradApp.emerald]),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: AwradApp.gold),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        completed >= total ? 'تم الورد كاملًا بحمد الله' : 'أتممت $completed من $total خطوة',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                      ),
                      const SizedBox(height: 11),
                      LinearProgressIndicator(
                        value: progress,
                        minHeight: 9,
                        borderRadius: BorderRadius.circular(20),
                        color: AwradApp.gold,
                        backgroundColor: const Color(0xFF315D50),
                      ),
                      const SizedBox(height: 13),
                      FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFE7A4), foregroundColor: AwradApp.emeraldDark),
                        onPressed: () => _openAt(startIndex),
                        icon: const Icon(Icons.play_arrow_rounded),
                        label: Text(completed == 0 ? 'ابدأ من البداية' : (completed >= total ? 'قراءة الورد من البداية' : 'متابعة الورد')),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                const _SectionTitle(title: 'ترتيب الورد'),
                const SizedBox(height: 8),
                ...List.generate(fullWirdSequence.length, (index) {
                  final item = fullWirdSequence[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: const Color(0xFFF4EBD5),
                          child: Text('${index + 1}', style: const TextStyle(color: AwradApp.emeraldDark, fontWeight: FontWeight.w900)),
                        ),
                        title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                        subtitle: Text('${item.category} • ${item.target} مرة'),
                        trailing: const Icon(Icons.chevron_left_rounded),
                        onTap: () => _openAt(index),
                      ),
                    ),
                  );
                }),
              ],
            ),
    );
  }
}

class FullWirdReaderScreen extends StatefulWidget {
  final int initialIndex;
  const FullWirdReaderScreen({super.key, required this.initialIndex});

  @override
  State<FullWirdReaderScreen> createState() => _FullWirdReaderScreenState();
}

class _FullWirdReaderScreenState extends State<FullWirdReaderScreen> {
  late int index;
  int count = 0;
  bool favorite = false;
  double fontSize = AppSettings.defaultFontSize.value;

  WirdItem get item => fullWirdSequence[index];

  @override
  void initState() {
    super.initState();
    index = widget.initialIndex.clamp(0, fullWirdSequence.length - 1);
    _loadCurrent();
  }

  Future<void> _loadCurrent() async {
    final c = await CounterStore.getCount(item.id);
    final f = await CounterStore.isFavorite(item.id);
    if (!mounted) return;
    setState(() {
      count = c;
      favorite = f;
    });
  }

  Future<void> _increment() async {
    if (count >= item.target) return;
    if (AppSettings.haptics.value) HapticFeedback.selectionClick();
    final nextCount = count + 1;
    setState(() => count = nextCount);
    await CounterStore.setCount(item.id, nextCount);
    if (nextCount >= item.target) {
      if (AppSettings.haptics.value) HapticFeedback.mediumImpact();
      if (index < fullWirdSequence.length - 1 && mounted) {
        await Future.delayed(const Duration(milliseconds: 250));
        setState(() {
          index++;
          count = 0;
          favorite = false;
        });
        await _loadCurrent();
      } else if (mounted) {
        showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            icon: const Icon(Icons.auto_awesome_rounded, color: AwradApp.gold, size: 46),
            title: const Text('تم الورد كاملًا بحمد الله', textAlign: TextAlign.center),
            content: const Text('نسأل الله القبول والنفع والبركة.', textAlign: TextAlign.center),
            actionsAlignment: MainAxisAlignment.center,
            actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('الحمد لله'))],
          ),
        );
      }
    }
  }

  Future<void> _previous() async {
    if (index == 0) return;
    setState(() => index--);
    await _loadCurrent();
  }

  Future<void> _next() async {
    if (index >= fullWirdSequence.length - 1) return;
    setState(() => index++);
    await _loadCurrent();
  }

  String _arNum(int n) {
    const western = '0123456789';
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    return n.toString().split('').map((c) {
      final i = western.indexOf(c);
      return i < 0 ? c : arabic[i];
    }).join();
  }

  @override
  Widget build(BuildContext context) {
    final done = count >= item.target;
    final progress = item.target == 0 ? 0.0 : (count / item.target).clamp(0.0, 1.0);
    return Scaffold(
      appBar: AppBar(
        title: const Text('الورد الكامل', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            onPressed: () async {
              setState(() => favorite = !favorite);
              await CounterStore.setFavorite(item.id, favorite);
            },
            icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            LinearProgressIndicator(
              value: (index + 1) / fullWirdSequence.length,
              minHeight: 6,
              color: AwradApp.gold,
              backgroundColor: const Color(0xFFECE6D8),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'الخطوة ${_arNum(index + 1)} من ${_arNum(fullWirdSequence.length)} • ${item.category}',
                          style: const TextStyle(color: AwradApp.emerald, fontWeight: FontWeight.w900),
                        ),
                      ),
                      IconButton(onPressed: fontSize <= 18 ? null : () => setState(() => fontSize -= 2), icon: const Icon(Icons.text_decrease_rounded)),
                      IconButton(onPressed: fontSize >= 35 ? null : () => setState(() => fontSize += 2), icon: const Icon(Icons.text_increase_rounded)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: const Color(0xFFE8D9B3)),
                    ),
                    child: Column(
                      children: [
                        Text(item.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, color: AwradApp.emeraldDark, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 12),
                        _WirdMetaStrip(item: item, targetText: '${_arNum(item.target)} مرة'),
                        const SizedBox(height: 15),
                        SelectableText(item.text, textAlign: TextAlign.center, style: TextStyle(fontSize: fontSize, height: 1.95, fontWeight: FontWeight.w700)),
                        if (item.source != null) ...[
                          const SizedBox(height: 14),
                          Text(item.source!, style: const TextStyle(color: AwradApp.emerald, fontWeight: FontWeight.w800)),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  InkWell(
                    onTap: done ? _next : _increment,
                    borderRadius: BorderRadius.circular(28),
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: AwradApp.emeraldDark,
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: AwradApp.gold),
                      ),
                      child: Column(
                        children: [
                          Text(done ? 'تم هذا الذكر ✓ — اضغط للانتقال' : 'اضغط هنا مع كل تكرار', style: const TextStyle(color: Color(0xFFFFE7A4), fontWeight: FontWeight.w900, fontSize: 17)),
                          const SizedBox(height: 10),
                          Text('${_arNum(count)} / ${_arNum(item.target)}', style: const TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 12),
                          LinearProgressIndicator(value: progress, minHeight: 9, borderRadius: BorderRadius.circular(20), color: AwradApp.gold, backgroundColor: const Color(0xFF315D50)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
              color: Colors.white,
              child: Row(
                children: [
                  Expanded(child: OutlinedButton.icon(onPressed: index == 0 ? null : _previous, icon: const Icon(Icons.arrow_forward_rounded), label: const Text('السابق'))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton.icon(onPressed: index >= fullWirdSequence.length - 1 ? null : _next, icon: const Icon(Icons.arrow_back_rounded), label: const Text('التالي'))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class WirdTodayScreen extends StatefulWidget {
  const WirdTodayScreen({super.key});

  @override
  State<WirdTodayScreen> createState() => _WirdTodayScreenState();
}

class _WirdTodayScreenState extends State<WirdTodayScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('وِردي اليوم', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView.separated(
        padding: const EdgeInsets.all(14),
        itemCount: wirdItems.length,
        separatorBuilder: (_, __) => const SizedBox(height: 9),
        itemBuilder: (_, index) => WirdListTile(item: wirdItems[index]),
      ),
    );
  }
}

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<WirdItem> favorites = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = <WirdItem>[];
    for (final item in allItems) {
      if (await CounterStore.isFavorite(item.id)) result.add(item);
    }
    if (mounted) setState(() => favorites = result);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة', style: TextStyle(fontWeight: FontWeight.w900))),
      body: favorites.isEmpty
          ? const Center(child: Text('لم تضف أي ورد إلى المفضلة بعد.'))
          : ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: favorites.length,
              separatorBuilder: (_, __) => const SizedBox(height: 9),
              itemBuilder: (_, index) => WirdListTile(item: favorites[index]),
            ),
    );
  }
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المزيد', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _MoreTile(
            icon: Icons.auto_stories_rounded,
            title: 'الورد الكامل المتتابع',
            subtitle: 'بدء الورد من الافتتاح حتى الختام مع حفظ موضعك',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FullWirdSessionScreen())),
          ),
          _MoreTile(
            icon: Icons.mosque_rounded,
            title: 'ورد بعد صلاة الجمعة',
            subtitle: '${fridayItems.length} عنصرًا بالعدادات',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const WirdListScreen(title: 'ورد بعد صلاة الجمعة', items: fridayItems))),
          ),
          _MoreTile(
            icon: Icons.settings_rounded,
            title: 'الإعدادات والتنبيهات',
            subtitle: 'الوضع الليلي، الخط، الاهتزاز، وتذكير الأوراد',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
          _MoreTile(
            icon: Icons.restart_alt_rounded,
            title: 'تصفير تقدم الورد الأساسي',
            subtitle: 'إعادة جميع العدادات إلى الصفر',
            onTap: () async {
              final ok = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('تصفير جميع العدادات'),
                      content: const Text('سيتم حذف تقدم جميع الأوراد. هل تريد المتابعة؟'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تصفير الجميع')),
                      ],
                    ),
                  ) ??
                  false;
              if (ok) await CounterStore.resetAll();
            },
          ),
          _MoreTile(
            icon: Icons.people_alt_outlined,
            title: 'عن الشيخين',
            subtitle: 'الصور والأسماء المعتمدة في واجهة التطبيق',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SheikhsInfoScreen())),
          ),
          _MoreTile(
            icon: Icons.menu_book_outlined,
            title: 'منهج نقل الأوراد',
            subtitle: 'ترتيب الكتيب، الأعداد، والتمييز بين الأصل والتوابع',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BookletMethodScreen())),
          ),
          _MoreTile(
            icon: Icons.info_outline_rounded,
            title: 'عن التطبيق',
            subtitle: 'أوراد الأنوار المحمدية — نسخة تجريبية',
            onTap: () => showAboutDialog(
              context: context,
              applicationName: 'أوراد الأنوار المحمدية',
              applicationVersion: '1.1.0',
              children: const [
                Text('إعداد/ د. أحمد حسن البحراوي\n\nنسخة تجريبية محسّنة، تعرض رقم الورد في الكتيب والعدد المطلوب والتوابع بصورة واضحة، مع الورد الكامل المتتابع والعدادات المستقلة والبحث والمفضلة وحفظ التقدم محليًا.'),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF3D9),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFE5C77F)),
            ),
            child: const Text(
              'تنبيه المراجعة: نُقلت النصوص من صور الكتيب قدر المستطاع، وتحتاج النسخة النهائية إلى مطابقة جميع الآيات والأعداد والنصوص على الأصل قبل النشر العام.',
              style: TextStyle(height: 1.6, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _fmt(TimeOfDay t) {
    final h = t.hourOfPeriod == 0 ? 12 : t.hourOfPeriod;
    final m = t.minute.toString().padLeft(2, '0');
    return '$h:$m ${t.period == DayPeriod.am ? 'ص' : 'م'}';
  }

  Future<void> _pickTime(bool morning) async {
    final initial = morning ? AppSettings.morningTime.value : AppSettings.eveningTime.value;
    final t = await showTimePicker(context: context, initialTime: initial);
    if (t == null) return;
    await AppSettings.setTime(morning, t);
    if (morning && AppSettings.morningReminder.value) {
      await NotificationService.scheduleDaily(id: 101, title: 'أوراد الأنوار المحمدية', body: 'حان وقت وِرد الصباح وذكر الله.', time: t);
    } else if (!morning && AppSettings.eveningReminder.value) {
      await NotificationService.scheduleDaily(id: 102, title: 'أوراد الأنوار المحمدية', body: 'حان وقت وِرد المساء وذكر الله.', time: t);
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات والتنبيهات', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const _SectionTitle(title: 'المظهر والقراءة'),
          const SizedBox(height: 8),
          ValueListenableBuilder<bool>(
            valueListenable: AppSettings.darkMode,
            builder: (_, v, __) => SwitchListTile(
              value: v,
              title: const Text('الوضع الليلي', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('واجهة داكنة مريحة للقراءة ليلًا'),
              secondary: const Icon(Icons.dark_mode_rounded),
              onChanged: (x) => AppSettings.setBool('dark_mode', AppSettings.darkMode, x),
            ),
          ),
          ValueListenableBuilder<bool>(
            valueListenable: AppSettings.haptics,
            builder: (_, v, __) => SwitchListTile(
              value: v,
              title: const Text('اهتزاز العداد', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('اهتزاز خفيف مع كل ضغطة وعند اكتمال الورد'),
              secondary: const Icon(Icons.vibration_rounded),
              onChanged: (x) => AppSettings.setBool('haptics', AppSettings.haptics, x),
            ),
          ),
          ValueListenableBuilder<double>(
            valueListenable: AppSettings.defaultFontSize,
            builder: (_, v, __) => Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('حجم خط الأذكار الافتراضي: ${v.round()}', style: const TextStyle(fontWeight: FontWeight.w900)),
                  Slider(value: v, min: 18, max: 34, divisions: 16, onChanged: (x) => AppSettings.setFont(x)),
                  Text('سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', style: TextStyle(fontSize: v, height: 1.7)),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const _SectionTitle(title: 'التنبيهات اليومية'),
          const SizedBox(height: 8),
          ValueListenableBuilder<bool>(
            valueListenable: AppSettings.morningReminder,
            builder: (_, v, __) => SwitchListTile(
              value: v,
              title: const Text('تذكير الصباح', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('الوقت: ${_fmt(AppSettings.morningTime.value)} — اضغط لتغيير الوقت'),
              secondary: const Icon(Icons.wb_sunny_outlined),
              onChanged: (x) async {
                await AppSettings.setBool('morning_reminder', AppSettings.morningReminder, x);
                if (x) {
                  await NotificationService.scheduleDaily(id: 101, title: 'أوراد الأنوار المحمدية', body: 'حان وقت وِرد الصباح وذكر الله.', time: AppSettings.morningTime.value);
                } else { await NotificationService.cancel(101); }
                if (mounted) setState(() {});
              },
            ),
          ),
          ListTile(leading: const Icon(Icons.schedule_rounded), title: const Text('تغيير وقت تذكير الصباح'), trailing: Text(_fmt(AppSettings.morningTime.value)), onTap: () => _pickTime(true)),
          ValueListenableBuilder<bool>(
            valueListenable: AppSettings.eveningReminder,
            builder: (_, v, __) => SwitchListTile(
              value: v,
              title: const Text('تذكير المساء', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('الوقت: ${_fmt(AppSettings.eveningTime.value)} — اضغط لتغيير الوقت'),
              secondary: const Icon(Icons.nights_stay_outlined),
              onChanged: (x) async {
                await AppSettings.setBool('evening_reminder', AppSettings.eveningReminder, x);
                if (x) {
                  await NotificationService.scheduleDaily(id: 102, title: 'أوراد الأنوار المحمدية', body: 'حان وقت وِرد المساء وذكر الله.', time: AppSettings.eveningTime.value);
                } else { await NotificationService.cancel(102); }
                if (mounted) setState(() {});
              },
            ),
          ),
          ListTile(leading: const Icon(Icons.schedule_rounded), title: const Text('تغيير وقت تذكير المساء'), trailing: Text(_fmt(AppSettings.eveningTime.value)), onTap: () => _pickTime(false)),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('يمكن إيقاف أي تنبيه في أي وقت. جميع إعدادات التطبيق وحالة العدادات محفوظة محليًا على الهاتف.', style: TextStyle(height: 1.6)),
            ),
          ),
        ],
      ),
    );
  }
}

class SheikhsInfoScreen extends StatelessWidget {
  const SheikhsInfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عن الشيخين', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _ScholarInfoCard(
            image: 'assets/images/sheikh_abdelrahim.jpg',
            name: 'العارف بالله الشيخ عبدالرحيم إبراهيم البحراوي',
          ),
          SizedBox(height: 14),
          _ScholarInfoCard(
            image: 'assets/images/sheikh_ibrahim.jpg',
            name: 'العارف بالله الشيخ إبراهيم عبدالرحيم البحراوي',
          ),
          SizedBox(height: 18),
          Text(
            'تُعرض الصور والأسماء كما تم اعتمادها لتكون جزءًا من الهوية البصرية لتطبيق أوراد الأنوار المحمدية.',
            textAlign: TextAlign.center,
            style: TextStyle(height: 1.7, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _ScholarInfoCard extends StatelessWidget {
  final String image;
  final String name;
  const _ScholarInfoCard({required this.image, required this.name});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AwradApp.gold, width: 1.4),
        boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 12, offset: Offset(0, 5))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          AspectRatio(aspectRatio: 1.35, child: Image.asset(image, fit: BoxFit.cover, alignment: Alignment.topCenter)),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(15),
            color: AwradApp.emeraldDark,
            child: Text(name, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 18, height: 1.5, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class BookletMethodScreen extends StatelessWidget {
  const BookletMethodScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('منهج نقل الأوراد', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _MethodCard(icon: Icons.format_list_numbered_rtl_rounded, title: 'ترقيم الكتيب', text: 'يُحفظ رقم الورد كما ورد في الكتيب. أما العبارات التابعة لعبارة «ثم يقول المريد» فلها عداد مستقل، وتظهر باعتبارها تابعًا للورد السابق دون تغيير رقم الكتيب.'),
          _MethodCard(icon: Icons.touch_app_rounded, title: 'العدادات', text: 'لكل نص عدد مستهدف مستقل. يتوقف العداد عند العدد المطلوب، ويحفظ التطبيق آخر قيمة تلقائيًا على الهاتف.'),
          _MethodCard(icon: Icons.auto_stories_rounded, title: 'الآيات والسور', text: 'إذا كان الورد سورة أو آية كاملة، فإتمام القراءة مرة واحدة يُحسب تكرارًا واحدًا، ثم تُزاد قيمة العداد.'),
          _MethodCard(icon: Icons.verified_outlined, title: 'المراجعة النهائية', text: 'قبل الإصدار العام، تُطابق الآيات والسور والأعداد والنصوص مع أصل الكتيب ومصدر قرآني موثوق، ولا يُعتمد أي نص غير واضح من الصورة بالتخمين.'),
        ],
      ),
    );
  }
}

class _MethodCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  const _MethodCard({required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(backgroundColor: const Color(0xFFF4EBD5), child: Icon(icon, color: AwradApp.emerald)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(text, style: const TextStyle(height: 1.7)),
            ])),
          ],
        ),
      ),
    );
  }
}

class _MoreTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _MoreTile({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFF4EBD5),
          child: Icon(icon, color: AwradApp.emerald),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: onTap,
      ),
    );
  }
}
