# إعداد إشعارات Android عند إنشاء مشروع Flutter الكامل

يعتمد الإصدار 1.1 على flutter_local_notifications + timezone + flutter_timezone.

في Android 13 فأعلى يجب السماح بالإشعارات عند أول تفعيل للتذكير، والتطبيق يطلب الإذن تلقائيًا.
إذا أنشأت مجلد android من جديد بواسطة flutter create، راجع تعليمات flutter_local_notifications لإضافة أي إعدادات مطلوبة بحسب إصدار Android/Gradle المستخدم.
